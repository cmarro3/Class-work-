#include <iostream>
//Christopher Marroquin
//12/02/18
//Week 2 assignment
using namespace std;

int main()
{
    int x;
    int sum = 0;
 do
 {

     system ("color c");
    // Please type in a number
    cout << "Enter a number (Enter 0 when done): " ;
    cin >> x ;


    // Add number to the sum
    sum = x + sum;
    // Please type in another number
}
while (x!= 0);
// Display number
cout << "Your sum is: " << sum << endl;
    return 0;
}
